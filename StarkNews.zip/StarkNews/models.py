from ext import db
from flask_login import UserMixin


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    name = db.Column(db.String, nullable=False)
    surname = db.Column(db.String, nullable=False)
    email = db.Column(db.String, unique=True, nullable=False)
    profile_url = db.Column(db.String)
    is_admin = db.Column(db.Boolean, default=False)

    articles = db.relationship(
        "Article",
        backref="author"
    )
    likes = db.relationship(
        "Like",
        backref="user"
    )


class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, nullable=False)
    content = db.Column(db.Text, nullable=False)
    img_url = db.Column(db.String)
    date = db.Column(db.String)
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    likes = db.relationship(
        "Like",
        backref="article",
        cascade="all, delete-orphan"
    )

    @property
    def likes_count(self):
        return len(self.likes)


class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    article_id = db.Column(db.Integer, db.ForeignKey("article.id"))
